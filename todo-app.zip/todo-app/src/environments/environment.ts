// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
  apiKey: "AIzaSyC9QecV0bheChwm3hIkf_MluyI_SB3N95I",
    authDomain: "angularhostinghw2.firebaseapp.com",
    databaseURL: "https://angularhostinghw2.firebaseio.com",
    projectId: "angularhostinghw2",
    storageBucket: "angularhostinghw2.appspot.com",
    messagingSenderId: "706474938167",
    appId: "1:706474938167:web:0c79db3f196e9e6e65d4b2",
    measurementId: "G-BG8LG2JH72"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
