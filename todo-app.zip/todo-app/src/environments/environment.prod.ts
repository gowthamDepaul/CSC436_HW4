export const environment = {
  production: true,
  firebase: {
  apiKey: "AIzaSyC9QecV0bheChwm3hIkf_MluyI_SB3N95I",
    authDomain: "angularhostinghw2.firebaseapp.com",
    databaseURL: "https://angularhostinghw2.firebaseio.com",
    projectId: "angularhostinghw2",
    storageBucket: "angularhostinghw2.appspot.com",
    messagingSenderId: "706474938167",
    appId: "1:706474938167:web:0c79db3f196e9e6e65d4b2",
    measurementId: "G-BG8LG2JH72"
  }
};
